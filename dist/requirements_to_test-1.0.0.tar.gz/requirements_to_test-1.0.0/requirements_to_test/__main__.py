"""
Command line entry point for Requirements to Test Generator.
Allows the package to be run as: python -m requirements_to_test
"""

from .gui import main

if __name__ == '__main__':
    main() 